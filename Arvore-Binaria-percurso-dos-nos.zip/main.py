import time

class arvore:
  def arvore(self):
    arvore.a = arvore
    arvore.chave = [0 for j in range(len(arvore.a))]
    arvore.filho_esquerda = [0 for j in range(len(arvore.a))]
    arvore.filho_direita = [0 for j in range(len(arvore.a))]
    for i in range(0, len(arvore.a)):
      arvore.chave[i] = arvore.a[i][1]
      arvore.filho_esquerda[i] = arvore.a[i][0]
      arvore.filho_direita[i] = arvore.a[i][3]
      arvore.raiz = arvore.a[3]
def arvore_percorre(b):
  for p in range(1):
    x = b
    print("Árvore.raiz na função percorre: ", x)

    if(x[1] <= arvore.raiz[1] ) and (x[1] != -20):
      print("Chave = ", x[1])
      arvore_percorre(arvore.a[b[0]])
      break
    if(x[1] >= arvore.raiz[1] ) and (x[1] != -20):
      print("Chave = ", x[1])
      arvore_percorre(arvore.a[b[3]])

A = [[1,2,"Limão",1], [4,4 "Banana", -1], [0, 5, "Morango", 1], [2, 6, "Tangerina", 4], [-1,7, "Laranja", 5], [-1, 8, "Goiaba", 6],[-1, -20, "Fim", -1]]

arvore.arvore(A)
print("Árvore = ", arvore.a)
print("Chave = ", arvore.chave)
print("Filho esquerda = ", arvore.filho_esquerda)
print("Filho direita = ", arvore.filho_direita)
print("Raiz = ", arvore.raiz, "\n")
tempo_inicial = time.time()
arvore_percorre(arvore.raiz)
tempo_final = time.time()
print("Tempo de execução: ", tempo_final - tempo_inicial")
